/*
 * Proto_token-ids.h
 *
 *  Created on: 31-ott-2008
 *      Author: mark
 */

#ifndef PROTO_TOKENIDS_H_
#define PROTO_TOKENIDS_H_

//#include "Proto_token-ids.i"
#include "Calc_parser.tab.h"

#define TKN_TERMINATION 0
#define TKN_UNINITIALIZED 1
#define TKN_DUMMY 2

#endif /* PROTO_TOKENIDS_H_ */
